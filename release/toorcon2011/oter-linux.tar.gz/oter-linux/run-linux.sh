#!/bin/bash

java -d32 -jar oter-linux.jar 
