#!/bin/bash

java -XstartOnFirstThread -d32 -jar otertool.jar 
