#!/bin/bash

java -jar otertool.jar 
